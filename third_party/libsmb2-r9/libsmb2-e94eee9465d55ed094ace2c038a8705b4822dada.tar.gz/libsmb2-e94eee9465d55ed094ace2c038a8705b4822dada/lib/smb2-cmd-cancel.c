/* -*-  mode:c; tab-width:8; c-basic-offset:8; indent-tabs-mode:nil;  -*- */
/*
   Copyright (C) 2016 by Ronnie Sahlberg <ronniesahlberg@gmail.com>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2.1 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, see <http://www.gnu.org/licenses/>.
*/
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif

#ifdef HAVE_STRING_H
#include <string.h>
#endif

#ifdef STDC_HEADERS
#include <stddef.h>
#endif

#ifdef HAVE_TIME_H
#include <time.h>
#endif

#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#endif

#include "compat.h"

#include "smb2.h"
#include "libsmb2.h"
#include "libsmb2-private.h"

static int
smb2_encode_cancel_request(struct smb2_context *smb2,
                           struct smb2_pdu *pdu)
{
        uint8_t *buf;
        int len;
        struct smb2_iovec *iov;

        len = SMB2_CANCEL_REQUEST_SIZE;

        buf = calloc(len, sizeof(uint8_t));
        if (buf == NULL) {
                smb2_set_error(smb2, "Failed to allocate cancel buffer");
                return -1;
        }

        iov = smb2_add_iovector(smb2, &pdu->out, buf, len, free);
        if (iov == NULL) {
                smb2_set_error(smb2, "Failed to add iovector for cancel request");
                return -1;
        }

        smb2_set_uint16(iov, 0, SMB2_CANCEL_REQUEST_SIZE);

        return 0;
}

struct smb2_pdu *
smb2_cmd_cancel_async(struct smb2_context *smb2,
                      uint64_t msg_id,
                      smb2_command_cb cb, void *cb_data)
{
        struct smb2_pdu *pdu;
        struct smb2_pdu *req_pdu;

        req_pdu = smb2_find_pdu(smb2, msg_id);
        if (req_pdu == NULL) {
                smb2_set_error(smb2, "No pending pdu with message id %ju "
                               "to cancel", (uintmax_t)msg_id);
                return NULL;
        }

        pdu = smb2_allocate_pdu(smb2, SMB2_CANCEL, cb, cb_data);
        if (pdu == NULL) {
                return NULL;
        }

        if (smb2_encode_cancel_request(smb2, pdu)) {
                smb2_free_pdu(smb2, pdu);
                return NULL;
        }

        if (req_pdu->header.flags & SMB2_FLAGS_ASYNC_COMMAND) {
                /*
                 * The request being cancelled has already been marked
                 * asynchronous by an interim response, so it has to be
                 * identified by its AsyncId (MS-SMB2 2.2.30).
                 */
                pdu->header.flags |= SMB2_FLAGS_ASYNC_COMMAND;
                pdu->header.async.async_id = req_pdu->header.async.async_id;
                pdu->header.message_id = 0xffffffffffffffffULL;
        } else {
                /*
                 * Otherwise it is identified by the MessageId that was
                 * used for the original request.
                 */
                pdu->header.message_id = req_pdu->header.message_id;
        }

        if (smb2_pad_to_64bit(smb2, &pdu->out) != 0) {
                smb2_free_pdu(smb2, pdu);
                return NULL;
        }

        return pdu;
}
